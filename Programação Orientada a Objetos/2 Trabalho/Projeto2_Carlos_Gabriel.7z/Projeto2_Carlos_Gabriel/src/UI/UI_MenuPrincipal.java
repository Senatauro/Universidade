/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import sun.awt.X11.Screen;

/**
 *
 * @author cgsste
 */
public class UI_MenuPrincipal extends JFrame
{
    JPanel painel;
    JMenuBar barraMenu;
    JMenu menu_cadastro, menu_consultas, menu_relatorios, menu_sobre, menu_ajuda;
    JMenuItem menCad_endereco, menCad_clFis, menCad_clJur, menCad_sair;
    
    public UI_MenuPrincipal()
    {
        /*--- Criação do Menu ---*/
        barraMenu = new JMenuBar();
        menu_cadastro = new JMenu("Cadastro");
        menu_consultas = new JMenu("Consultas");
        menu_relatorios = new JMenu("Relatorios");
        menu_sobre = new JMenu("Sobre");
        menu_ajuda = new JMenu("Ajuda");
        /*--- Criação do Menu ---*/
        
        /*--- Criação das opções do menu ---*/
        menCad_endereco = new JMenuItem("Endereço");
        menCad_clFis = new JMenuItem("Clientes - Física");
        menCad_clJur = new JMenuItem("Clientes - Juridica");
        menCad_sair = new JMenuItem("Sair");
        /*--- Criação das opções do menu ---*/
        
        /*--- Adicionando os botões no menu ---*/
        menu_cadastro.add(menCad_endereco);
        menu_cadastro.add(menCad_clFis);
        menu_cadastro.add(menCad_clJur);
        menu_cadastro.add(menCad_sair);
        /*--- Adicionando os botões no menu ---*/
        
        /*--- Colocando menu ---*/
        super.setJMenuBar(this.barraMenu);
        barraMenu.add(this.menu_cadastro);
        /*--- Colocando menu ---*/
        
        //Criação do painel
        painel = new JPanel();
        
        super.add(painel);
        
        //Pegando tamanho da tela
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int width = (int)screenSize.getWidth();
        int height = (int)screenSize.getHeight();

        super.setTitle("Sistema de Controle de Clientes");
        super.setSize(width, height);
        super.setLocationRelativeTo(null);
        super.setDefaultCloseOperation(EXIT_ON_CLOSE);
        super.setVisible(true);
        
    }
}
