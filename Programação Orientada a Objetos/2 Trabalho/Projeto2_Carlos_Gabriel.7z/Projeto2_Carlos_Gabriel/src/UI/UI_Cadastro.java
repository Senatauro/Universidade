/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ComboBoxEditor;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.plaf.basic.BasicArrowButton;

/**
 *
 * @author cgsste
 */
public class UI_Cadastro extends JFrame
{
    //Label
    JLabel lab_codCl, lab_nomeCl, lab_cpCL, lab_limCredCl, lab_statusCl, lab_tempoCl;
    //Campos de texto
    JTextField txtF_codCl, txtF_nomeCl, txtF_cpCl, txtF_limCredCl, txtF_tempoCl;
    //Combo box
    JComboBox comb_statusCl;
    //Botoes
    JButton bt_incluir, bt_listar, bt_excluir, bt_anterior, bt_proximo, bt_sair;
    //Barra de menu
    JMenuBar barraMenu;
    //Menu
    JMenu menu;
    //Itens do menu
    JMenuItem men_incluir, men_listar, men_excluir, men_anterior, men_proximo, men_sair;
    //Paineis
    JPanel painel1, painel2;
    //Ações
    Action incluir, listar, excluir, anterior, proximo, sair;
    
    public UI_Cadastro(String tipoDePessoa, String tipoDePessoa2)
    {
        /*--- Criação dos Labels ---*/
        lab_codCl = new JLabel("Código:");
        lab_nomeCl = new JLabel("Nome do Cliente:");
        lab_cpCL = new JLabel(tipoDePessoa2 + ":");
        lab_limCredCl = new JLabel("Limite de Crédito:");
        lab_statusCl = new JLabel("Status:");
        lab_tempoCl = new JLabel("Cliente desde:");
        /*--- Criação dos Labels ---*/
        
        /*--- Criação dos TextField ---*/
        txtF_codCl = new JTextField();
        txtF_nomeCl = new JTextField();
        txtF_cpCl = new JTextField();
        txtF_limCredCl = new JTextField();
        txtF_tempoCl = new JTextField();
        /*--- Criação dos TextField ---*/
        
        /*--- Criação do comboBox ---*/
        String[] jota = {"Preferencial", "Ouro", "Prata", "Bronze"};
        comb_statusCl = new JComboBox(jota);
        /*--- Criação do comboBox ---*/
        
        /*--- Criação dos botoes ---*/
        bt_incluir = new JButton("Incluir");
        bt_listar = new JButton("Listar");
        bt_excluir = new JButton("Excluir");
        bt_anterior = new JButton("Anterior");
        bt_proximo = new JButton("Proximo");
        bt_sair = new JButton("Sair");
        /*--- Criação dos botoes ---*/
        
        /*--- Criação do menu ---*/
        barraMenu = new JMenuBar();
        menu = new JMenu("Opções");
        men_incluir = new JMenuItem("Incluir");
        men_listar = new JMenuItem("Listar");
        men_excluir = new JMenuItem("Excluir");
        men_anterior = new JMenuItem("Anterior");
        men_proximo = new JMenuItem("Proximo");
        men_sair = new JMenuItem("Sair");
        /*--- Criação do menu ---*/
        
        /*--- Criação dos Paineis ---*/
        painel1 = new JPanel();
        painel2 = new JPanel();
        /*--- Criação dos Paineis ---*/
        
        /*--- Definição das Ações ---*/
        incluir = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        listar = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        excluir = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        anterior = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        proximo = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        sair = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                System.out.println("testesas");
                fecharJanela();
            }
        };
        /*--- Definição das Ações ---*/
        
        /*--- Listeners dos botões ---*/
        bt_incluir.addActionListener(incluir);
        
        bt_listar.addActionListener(listar);
        
        bt_excluir.addActionListener(excluir);
        
        bt_anterior.addActionListener(anterior);
                
        bt_proximo.addActionListener(proximo);
        
        bt_sair.addActionListener(sair);
        /*--- Listeners dos botões ---*/
        
        /*--- Listeners dos botões do menu ---*/
        bt_incluir.addActionListener(incluir);
        bt_listar.addActionListener(listar);
        bt_excluir.addActionListener(excluir);
        bt_anterior.addActionListener(anterior);
        bt_proximo.addActionListener(proximo);
        bt_sair.addActionListener(sair);
        /*--- Listeners dos botões do menu ---*/
        
        //Coloca o painel1 como grid de 6 linhas por 2 colunas
        painel1.setLayout(new GridLayout(6,2));
        
        //Coloca o painel2 como grid de 1 linha por 6 colunas
        painel2.setLayout(new GridLayout(1,6));
        
        /*--- Adicionando os labels e textbox ao painel1 ---*/
        painel1.add(this.lab_codCl);
        painel1.add(this.txtF_codCl);
        painel1.add(this.lab_nomeCl);
        painel1.add(this.txtF_nomeCl);
        painel1.add(this.lab_cpCL);
        painel1.add(this.txtF_cpCl);
        painel1.add(this.lab_limCredCl);
        painel1.add(this.txtF_limCredCl);
        painel1.add(this.lab_statusCl);
        painel1.add(this.comb_statusCl);
        painel1.add(this.lab_tempoCl);
        painel1.add(this.txtF_tempoCl);
        /*--- Adicionando os labels e textbox ao painel1 ---*/
        
        /*--- Adicionando os menus ---*/
        super.setJMenuBar(this.barraMenu);
        barraMenu.add(this.menu);
        /*--- Adicionando os menus ---*/
        
        /*--- Adicionando os botões no menu ---*/
        menu.add(men_incluir);
        menu.add(men_listar);
        menu.add(men_excluir);
        menu.add(men_anterior);
        menu.add(men_proximo);
        menu.add(men_sair);
        /*--- Adicionando os botões no menu ---*/
        
        /*--- Adicioando botões ao painel2 ---*/
        painel2.add(this.bt_incluir);
        painel2.add(this.bt_listar);
        painel2.add(this.bt_excluir);
        painel2.add(this.bt_anterior);
        painel2.add(this.bt_proximo);
        painel2.add(this.bt_sair);        
        /*--- Adicioando botões ao painel2 ---*/
        
        /*--- Adicionando os paineis ao programa ---*/
        super.add(painel1, BorderLayout.CENTER);
        super.add(painel2, BorderLayout.SOUTH);
        /*--- Adicionando os paineis ao programa ---*/
        
        //Colocando painel principal como azul
        painel1.setBackground(Color.yellow);
        
        /*--- Configurações finais ---*/
        super.setTitle("Cadastro de Clientes - Pessoa " + tipoDePessoa);
        super.setSize(840, 240);
        super.setLocationRelativeTo(null);
        super.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        super.setVisible(true);
        /*--- Configurações finais ---*/
    }
    
    void fecharJanela()
    {
        System.out.println("teste");
        this.dispose();
    }
}
