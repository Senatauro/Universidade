/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author cgsste
 */
public abstract class Cliente 
{
    static int codigoCli;
    String nomeCli;
    
    Cliente(int codigo, String nome)
    {
        codigoCli = codigo;
        nomeCli = nome;
    }
    
    @Override
    public String toString()
    {
        return "Nome do Cliente:" + nomeCli + "   codigo: " + codigoCli; 
    }
}
