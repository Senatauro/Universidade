﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class PegarFrame : MonoBehaviour 
{
	//Material que contem o shader a ser usado no frame
	[SerializeField]Material mat;

	public bool aumentando = true;
	public float t = 0.5f;
	public float valor = 0;

	void Update()
	{
		if (aumentando) {
			print ("Aumentando");
			if (valor >= 500) {
				aumentando = false;
			}
			valor = Mathf.Lerp (valor, 501, t * Time.deltaTime);
		} else {
			print ("Diminuindo");
			if (valor <= 25) {
				aumentando = true;
			}
			valor = Mathf.Lerp (valor, 24, t * Time.deltaTime);
		}
		mat.SetFloat ("_Valor", valor);
	}

	//Função executada a cada frame sendo src(source) o frame inicial(antes de ser processado pelo shader)
	//e dest, o frame final(apos passar pelo processamento do shader)
	void OnRenderImage(RenderTexture src, RenderTexture dest)
	{
		//Pega o frame e seta como textura principal do material para o shader fazer a execucao
		Graphics.Blit (src, dest, mat);
	}

}
