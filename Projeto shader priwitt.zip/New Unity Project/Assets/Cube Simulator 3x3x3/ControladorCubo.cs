﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControladorCubo : MonoBehaviour 
{

	public int passoAtual = 0;
	public GameObject[] menus;
	/*
	public bool debug1;
	public bool debug2;
	public bool debug3;
	public bool debug4;
	public bool debug5;
	//Passo a passo
	/*
	 * iniciar com cubo bonito
	 * BAGUNÇAR
	 * Começar fazendo a cruz branca
	 * passo 2
	 * passo 3
	 * passo 4
	 * cubo finalizado
	*/
	// Use this for initialization
	public void MudarPasso()
	{
		passoAtual++;
		if (passoAtual == 1) 
		{
			menus [0].SetActive (false);
			menus [1].SetActive (true);
			//GameObject.Find ("Cube 3x3x3").GetComponent<CubeController>().onButtonClick("scramble");
		}
		if (passoAtual == 2) 
		{
			menus [1].SetActive (false);
			menus[2].SetActive(true);
			//GameObject.Find ("Cube 3x3x3").GetComponent<CubeController>().ResolverCuboPassoAPasso();
		}
		if (passoAtual == 3) 
		{
			menus [2].SetActive (false);
			menus[3].SetActive(true);
			//GameObject.Find ("Cube 3x3x3").GetComponent<CubeController>().ResolverCuboPassoAPasso();
		}
		if (passoAtual == 4) 
		{
			menus [3].SetActive (false);
			menus[4].SetActive(true);
			//GameObject.Find ("Cube 3x3x3").GetComponent<CubeController>().ResolverCuboPassoAPasso();
		}
		if (passoAtual == 5) 
		{
			menus [4].SetActive (false);
			menus[5].SetActive(true);
			//GameObject.Find ("Cube 3x3x3").GetComponent<CubeController>().ResolverCuboPassoAPasso();
		}
		if (passoAtual == 6) 
		{
			menus [5].SetActive (false);
			menus[6].SetActive(true);
//			GameObject.Find ("Cube 3x3x3").GetComponent<CubeController>().onButtonClick("scramble");
			//GameObject.Find ("Cube 3x3x3").GetComponent<CubeController>().ResolverCuboPassoAPasso();
		}
		if (passoAtual == 7) 
		{
			menus [6].SetActive (false);
			menus [7].SetActive (true);
		}
		if (passoAtual == 8) 
		{
			menus [7].SetActive (false);
			menus [8].SetActive (true);
			GameObject.Find ("Cube 3x3x3").GetComponent<CubeController>().onButtonClick("scramble");


		}
		if (passoAtual == 9) 
		{
			menus [8].SetActive (false);
			menus [9].SetActive (true);
			GameObject.Find ("Cube 3x3x3").GetComponent<CubeController>().ResolverCuboPassoAPasso();

		}
		if (passoAtual == 10) 
		{
			menus [9].SetActive (false);
			menus [10].SetActive (true);
			GameObject.Find ("Cube 3x3x3").GetComponent<CubeController> ().passo1 = false;
		}
		if (passoAtual == 11) 
		{
			menus [10].SetActive (false);
			menus [11].SetActive (true);
			GameObject.Find ("Cube 3x3x3").GetComponent<CubeController> ().passo2 = false;
		}
		if(passoAtual == 12)
		{
			menus [11].SetActive (false);
			menus [12].SetActive (true);
			GameObject.Find ("Cube 3x3x3").GetComponent<CubeController> ().passo3 = false;
		}
		if (passoAtual == 13) 
		{
			menus [12].SetActive (false);
			menus [13].SetActive (true);
			GameObject.Find ("Cube 3x3x3").GetComponent<CubeController> ().passo4 = false;
			GameObject.Find ("txt_Prox").GetComponent<UnityEngine.UI.Text> ().text = "Reiniciar";
		}
		if (passoAtual == 14) 
		{
			passoAtual = 0;
			menus [13].SetActive (false);
			menus [0].SetActive (true);
		}
	}

	public void MaisInfo(int op)
	{
		if (op == -1)
			Application.OpenURL ("https://ruwix.com/the-rubiks-cube/notation/");
		if (op == 0)
			Application.OpenURL ("https://ruwix.com/the-rubiks-cube/advanced-cfop-fridrich/");
		if (op == 1)
			Application.OpenURL ("https://ruwix.com/the-rubiks-cube/advanced-cfop-fridrich/white-cross/");
		if(op == 2)
			Application.OpenURL ("https://ruwix.com/the-rubiks-cube/advanced-cfop-fridrich/first-two-layers-f2l");
		if(op == 3)
			Application.OpenURL ("https://ruwix.com/the-rubiks-cube/advanced-cfop-fridrich/orient-the-last-layer-oll/");
		if (op == 4)
			Application.OpenURL ("https://ruwix.com/the-rubiks-cube/advanced-cfop-fridrich/permutate-the-last-layer-pll/");
	}
}