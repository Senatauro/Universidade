Prerequisites
=============
You need to ensure that a Java Runtime Environment, version 1.8 or newer, is 
installed on your system. GLIBC 2.14 is required on your system.

Installation
============
Some Linux systems, e.g. Ubuntu or Fedora, let you install the Java Runtime
Environment with their usual installation tools. If your system does not offer
this option, please download the latest Java Runtime Environment (JRE) from

 http://www.oracle.com/technetwork/java/javase/downloads/index.html
 
and install it. It needs not be installed for the whole machine, a private Java 
Runtime Environment in your home directory to run SmartGit is sufficient.

SmartGit itself does not need to be installed; just unpack it to your preferred
location and launch the bin/smartgit.sh script. It might be necessary to tell
SmartGit where it can find your Java Runtime Environment. Create the file
~/.smartgit/smartgit.vmoptions and add following line (change the path)

jre=/path/to/your/jre

HiDPI Screen
============
As a work-around for 

<https://bugs.eclipse.org/bugs/show_bug.cgi?id=508029> 

the auto-detection of the scaling seems not to work any more on Linux. Please
add following line to ~/.smartgit/smartgit.vmoptions: 

-Dsmartgit.gui.dpiFactor=2 


If you have further questions regarding the SmartGit on Linux, please ask in
our SmartGit mailing list:

http://www.syntevo.com/contact/
 
--
Your SyntEvo-team
www.syntevo.com/smartgit
